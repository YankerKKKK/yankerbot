const help1 = (prefix) => {

	return `
╭──────────────╮
     *🦊𝑵𝒆𝒌𝒐-𝒄𝒉𝒂𝒏🦊*
╰──────────────╯
 
➸ *${prefix}marcar*
➸ *${prefix}marcar2*
➸ *${prefix}marcar3*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}malkova*
➸ *${prefix}reislin*
➸ *${prefix}limpar*
➸ *${prefix}marcar*
➸ *${prefix}ts (texto que deseja transmitir)*

════════════════════
*𝐘𝐀𝐍𝐊𝐄𝐑 copyright©️ 2021愛* 

════════════════════`

}
exports.help1 = help1



