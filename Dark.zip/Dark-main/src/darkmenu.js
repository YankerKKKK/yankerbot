const darkmenu = (prefix) => {
	return `

            COMANDOS:


  *𝐘𝐀𝐍𝐊𝐄𝐑 𝐁𝐎𝐓 comandos:*

➸ *${prefix}loli*
➸ *${prefix}hentai*
➸ *${prefix}dono*
➸ *${prefix}porno*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}ayeko*

╔════════════════════
  TRADUZIDO POR *𝐘𝐀𝐍𝐊𝐄𝐑 𝐁𝐎𝐓*
  DUVIDAS? 👇
  WA.me/5511981875428
╚════════════════════`
}

exports.darkmenu = darkmenu










