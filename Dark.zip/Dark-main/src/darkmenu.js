const darkmenu = (prefix) => {
	return `

           


       *🦊𝑵𝒆𝒌𝒐-𝒄𝒉𝒂𝒏🦊*

➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}ayeko*

╔════════════════════
  TRADUZIDO POR *𝐘𝐀𝐍𝐊𝐄𝐑*

   𝐘𝐀𝐍𝐊𝐄𝐑 copyright©️ 2021

     DUVIDAS? chame meu onii-chan

  WA.me/5511981875428
╚════════════════════`
}

exports.darkmenu = darkmenu










