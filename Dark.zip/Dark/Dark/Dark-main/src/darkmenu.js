const darkmenu = (prefix) => {
	return `

   *🦊𝑵𝒆𝒌𝒐-𝑪𝒉𝒂𝒏 𝑩𝑶𝑻 á seu dispor🦊*

➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*

╔════════════════════
  TRADUZIDO POR *𝐘𝐀𝐍𝐊𝐄𝐑* 💮
  *🎭 Yanker Copyright©️🎭* 2021

  Alguma dúvida? chame meu dono

       WA.me/5511981875428
╚════════════════════`
}

exports.darkmenu = darkmenu












