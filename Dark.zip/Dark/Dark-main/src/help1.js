const help1 = (prefix) => {

	return `
────────────────────
  *𝑵𝒆𝒌𝒐-𝑪𝒉𝒂𝒏 𝑩𝑶𝑻* á seu dispor*
────────────────────
 
➸ *${prefix}marcar*
➸ *${prefix}marcar2*
➸ *${prefix}marcar3*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}akeno*
➸ *${prefix}meme*
➸ *${prefix}lofi*
➸ *${prefix}malkova*
➸ *${prefix}reislin*
➸ *${prefix}limpar*
➸ *${prefix}marcar*
➸ *${prefix}ts (texto que deseja transmitir)*

════════════════════
*𝑵𝒆𝒌𝒐-𝑪𝒉𝒂𝒏 𝑩𝑶𝑻 愛* 🦊
════════════════════`

}
exports.help1 = help1




